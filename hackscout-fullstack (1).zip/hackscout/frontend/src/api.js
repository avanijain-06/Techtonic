// ── API Service ─────────────────────────────────────────
// All calls go to the Express backend via the proxy defined in package.json

const BASE = '/api';

async function request(url, options = {}) {
  const res = await fetch(`${BASE}${url}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  });
  const data = await res.json();
  if (!data.success) throw new Error(data.message || 'API error');
  return data;
}

// Hackathons
export const getHackathons = (params = {}) => {
  const qs = new URLSearchParams(
    Object.fromEntries(Object.entries(params).filter(([, v]) => v && v !== 'All'))
  ).toString();
  return request(`/hackathons${qs ? `?${qs}` : ''}`);
};

export const getHackathon = (id) => request(`/hackathons/${id}`);

export const addHackathon = (body) =>
  request('/hackathons', { method: 'POST', body: JSON.stringify(body) });

export const deleteHackathon = (id) =>
  request(`/hackathons/${id}`, { method: 'DELETE' });

// Meta
export const getTags  = () => request('/tags');
export const getStats = () => request('/stats');

// AI
export const askHackBot = (query) =>
  request('/ai/chat', { method: 'POST', body: JSON.stringify({ query }) });
