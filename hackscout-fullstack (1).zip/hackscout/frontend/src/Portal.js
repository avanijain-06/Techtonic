import { useState, useEffect, useCallback } from 'react';
import { getHackathons, addHackathon, getTags, getStats, askHackBot } from './api';

const TAG_COLORS = {
  national:'#f59e0b', government:'#10b981', edtech:'#6366f1', corporate:'#3b82f6',
  ai:'#8b5cf6', online:'#06b6d4', college:'#ec4899', offline:'#f97316', open:'#14b8a6',
  competitive:'#ef4444', global:'#a78bfa', coding:'#0ea5e9', local:'#84cc16',
  agritech:'#22c55e', startup:'#f43f5e', hybrid:'#fb923c',
};

const AI_SUGGESTIONS = [
  { name:'Google Solution Challenge 2025', why:'Trending globally — 10,000+ student registrations. Matches AI and sustainability interests.', deadline:'2025-03-22', link:'https://developers.google.com/community/gdsc-solution-challenge', badge:'🔥 Hot' },
  { name:'Microsoft Imagine Cup 2025', why:'Cash prizes + Azure credits + global mentorship. Perfect for impactful tech.', deadline:'2025-04-30', link:'https://imaginecup.microsoft.com', badge:'⭐ Top Pick' },
  { name:'DevPost Global Hackathon Series', why:'Multiple online hackathons running simultaneously. Flexible for remote participation.', deadline:'Rolling', link:'https://devpost.com/hackathons', badge:'🌐 Always On' },
  { name:'Flipkart GRiD 6.0', why:"India's biggest e-commerce hackathon — great for supply chain, AI & ML.", deadline:'2025-07-15', link:'https://unstop.com/flipkart-grid', badge:'🏆 High Reward' },
];

const daysUntil = (d) => Math.ceil((new Date(d) - new Date()) / 86400000);
const fmtDate = (d) => new Date(d).toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' });

// ── Loading skeleton ────────────────────────────────────
function Skeleton() {
  return (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(320px,1fr))', gap:16 }}>
      {[1,2,3].map(i => (
        <div key={i} style={{ background:'#131620', border:'1px solid #1e2235', borderRadius:16, padding:20, height:220 }}>
          <div style={{ background:'#1e2235', borderRadius:8, height:16, width:'60%', marginBottom:12, animation:'shimmer 1.5s infinite' }}/>
          <div style={{ background:'#1e2235', borderRadius:8, height:12, width:'40%', marginBottom:8 }}/>
          <div style={{ background:'#1e2235', borderRadius:8, height:12, width:'80%', marginBottom:8 }}/>
          <div style={{ background:'#1e2235', borderRadius:8, height:12, width:'70%' }}/>
        </div>
      ))}
    </div>
  );
}

export default function Portal() {
  const [hackathons, setHackathons] = useState([]);
  const [stats, setStats] = useState({ total:0, online:0, offline:0, featured:0 });
  const [allTags, setAllTags] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [search, setSearch] = useState('');
  const [modeFilter, setModeFilter] = useState('All');
  const [tagFilter, setTagFilter] = useState('All');
  const [activeTab, setActiveTab] = useState('discover');

  const [aiLoading, setAiLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState('');
  const [aiQuery, setAiQuery] = useState('');

  const [form, setForm] = useState({ name:'', organizer:'', theme:'', mode:'Online', location:'', startDate:'', endDate:'', deadline:'', prize:'', description:'', registrationLink:'', tags:'' });
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [modal, setModal] = useState(null);

  // Fetch hackathons from backend
  const fetchData = useCallback(async () => {
    setLoading(true); setError('');
    try {
      const [hackRes, statsRes, tagsRes] = await Promise.all([
        getHackathons({ search, mode: modeFilter, tag: tagFilter }),
        getStats(),
        getTags(),
      ]);
      setHackathons(hackRes.data);
      setStats(statsRes.data);
      setAllTags(tagsRes.data);
    } catch (e) {
      setError('⚠️ Could not connect to server. Make sure the backend is running on port 5000.');
    }
    setLoading(false);
  }, [search, modeFilter, tagFilter]);

  useEffect(() => { fetchData(); }, [fetchData]);

  // Debounce search
  useEffect(() => {
    const t = setTimeout(fetchData, 400);
    return () => clearTimeout(t);
  }, [search]); // eslint-disable-line

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await addHackathon({
        ...form,
        tags: form.tags.split(',').map(t => t.trim().toLowerCase()).filter(Boolean),
      });
      setSubmitted(true);
      fetchData(); // refresh list
      setTimeout(() => {
        setSubmitted(false);
        setForm({ name:'', organizer:'', theme:'', mode:'Online', location:'', startDate:'', endDate:'', deadline:'', prize:'', description:'', registrationLink:'', tags:'' });
      }, 2500);
    } catch (e) {
      alert('Failed to add hackathon: ' + e.message);
    }
    setSubmitting(false);
  };

  const handleAskAI = async () => {
    if (!aiQuery.trim()) return;
    setAiLoading(true); setAiResponse('');
    try {
      const res = await askHackBot(aiQuery);
      setAiResponse(res.data.response);
    } catch {
      setAiResponse('⚠️ Could not connect to AI. Make sure backend is running.');
    }
    setAiLoading(false);
  };

  return (
    <div style={{ minHeight:'100vh', background:'#0d0f14', color:'#e2e8f0' }}>
      {/* Header */}
      <div style={{ background:'#0a0c10', borderBottom:'1px solid #1e2235', position:'sticky', top:0, zIndex:40 }}>
        <div style={{ maxWidth:1100, margin:'0 auto', padding:'14px 20px', display:'flex', alignItems:'center', justifyContent:'space-between', flexWrap:'wrap', gap:12 }}>
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <div style={{ width:36, height:36, borderRadius:10, background:'linear-gradient(135deg,#7c3aed,#06b6d4)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:18 }}>⚡</div>
            <div>
              <div style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:18, fontWeight:700, color:'#fff' }}>HackScout</div>
              <div style={{ fontSize:10, color:'#64748b' }}>Hackathon Discovery Portal</div>
            </div>
          </div>
          <div style={{ display:'flex', gap:4, flexWrap:'wrap' }}>
            {[['discover','🔍 Discover'],['ai-assist','🤖 AI Assist'],['add','➕ Add Hackathon']].map(([id,label])=>(
              <button key={id} className={`tab-btn ${activeTab===id?'active':''}`} onClick={()=>setActiveTab(id)}>{label}</button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ maxWidth:1100, margin:'0 auto', padding:'0 20px 80px' }}>

        {/* ── DISCOVER ── */}
        {activeTab === 'discover' && (
          <div className="pfade">
            {/* Hero */}
            <div style={{ position:'relative', padding:'48px 0 32px', overflow:'hidden' }}>
              <div className="hero-glow" style={{ top:-100, left:'50%', transform:'translateX(-50%)' }}/>
              <div style={{ textAlign:'center', position:'relative' }}>
                <div style={{ display:'inline-block', background:'#1e2235', border:'1px solid #3730a3', borderRadius:20, padding:'4px 16px', fontSize:12, color:'#a78bfa', fontWeight:600, marginBottom:16 }}>
                  🚀 {stats.total} Hackathons Listed
                </div>
                <h1 style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:'clamp(28px,5vw,48px)', fontWeight:700, color:'#fff', lineHeight:1.1, marginBottom:12 }}>
                  Never Miss a<br/>
                  <span style={{ background:'linear-gradient(90deg,#a78bfa,#06b6d4)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>Hackathon Again</span>
                </h1>
                <p style={{ color:'#64748b', fontSize:16, maxWidth:500, margin:'0 auto' }}>Your centralized hub for discovering, sharing, and joining hackathons — powered by a real backend.</p>
              </div>
            </div>

            {/* Stats */}
            <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(120px,1fr))', gap:12, marginBottom:28 }}>
              {[{l:'Total',v:stats.total,i:'📋'},{l:'Online',v:stats.online,i:'💻'},{l:'Offline',v:stats.offline,i:'🏛️'},{l:'Featured',v:stats.featured,i:'⭐'}].map(s=>(
                <div key={s.l} className="stat-card">
                  <div style={{ fontSize:22 }}>{s.i}</div>
                  <div style={{ fontSize:24, fontWeight:700, color:'#fff', fontFamily:"'Space Grotesk',sans-serif" }}>{s.v}</div>
                  <div style={{ fontSize:11, color:'#64748b', fontWeight:600, textTransform:'uppercase' }}>{s.l}</div>
                </div>
              ))}
            </div>

            {/* Filters */}
            <div style={{ background:'#131620', border:'1px solid #1e2235', borderRadius:16, padding:20, marginBottom:24 }}>
              <input className="pinput" placeholder="🔍  Search by name, theme, location, organizer..." value={search} onChange={e=>setSearch(e.target.value)} style={{ marginBottom:14, fontSize:15 }}/>
              <div style={{ display:'flex', gap:8, flexWrap:'wrap', alignItems:'center' }}>
                <span style={{ fontSize:12, color:'#64748b', fontWeight:600, marginRight:4 }}>MODE:</span>
                {['All','Online','Offline','Hybrid'].map(m=>(
                  <button key={m} className={`btn-ghost ${modeFilter===m?'gactive':''}`} onClick={()=>setModeFilter(m)}>{m}</button>
                ))}
                <span style={{ fontSize:12, color:'#64748b', fontWeight:600, marginLeft:12, marginRight:4 }}>TAG:</span>
                <select className="pselect" value={tagFilter} onChange={e=>setTagFilter(e.target.value)} style={{ width:'auto', padding:'7px 12px' }}>
                  <option>All</option>
                  {allTags.map(t=><option key={t} value={t}>{t}</option>)}
                </select>
                {(search||modeFilter!=='All'||tagFilter!=='All') && (
                  <button className="btn-ghost" onClick={()=>{setSearch('');setModeFilter('All');setTagFilter('All');}} style={{ color:'#f43f5e', borderColor:'#f43f5e33' }}>✕ Clear</button>
                )}
              </div>
            </div>

            {error && <div style={{ background:'#2d1515', border:'1px solid #f43f5e44', borderRadius:12, padding:16, marginBottom:20, color:'#f87171', fontSize:14 }}>{error}</div>}

            {loading ? <Skeleton /> : hackathons.length === 0 ? (
              <div style={{ textAlign:'center', padding:60, color:'#475569' }}>
                <div style={{ fontSize:40, marginBottom:12 }}>🔭</div>
                <div style={{ fontSize:18, fontWeight:600 }}>No hackathons found</div>
                <div style={{ fontSize:14, marginTop:6 }}>Try adjusting filters or add one!</div>
              </div>
            ) : (
              <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(320px,1fr))', gap:16 }}>
                {hackathons.map(h => {
                  const days = daysUntil(h.deadline);
                  const dc = days<0?'':days<7?'dl-urgent':days<21?'dl-soon':'dl-ok';
                  return (
                    <div key={h.id} className="hcard" onClick={()=>setModal(h)}>
                      {h.featured && <div style={{ position:'absolute', top:12, right:12, background:'linear-gradient(135deg,#f59e0b,#fbbf24)', color:'#000', fontSize:10, fontWeight:700, padding:'2px 8px', borderRadius:20 }}>⭐ FEATURED</div>}
                      <div style={{ display:'flex', gap:8, flexWrap:'wrap', marginBottom:12 }}>
                        {h.tags.slice(0,3).map(t=><span key={t} className="htag" style={{ background:(TAG_COLORS[t]||'#a78bfa')+'22', color:TAG_COLORS[t]||'#a78bfa', border:`1px solid ${(TAG_COLORS[t]||'#a78bfa')}44` }}>{t}</span>)}
                      </div>
                      <h3 style={{ fontSize:16, fontWeight:700, color:'#f1f5f9', marginBottom:4, lineHeight:1.3 }}>{h.name}</h3>
                      <div style={{ fontSize:12, color:'#64748b', marginBottom:12 }}>{h.organizer}</div>
                      <div style={{ fontSize:13, color:'#94a3b8', marginBottom:14, lineHeight:1.5 }}>{h.description}</div>
                      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:14 }}>
                        {[{i:'📅',l:fmtDate(h.startDate)},{i:'📍',l:h.location},{i:'💻',l:h.mode},{i:'🏆',l:h.prize||'TBA'}].map((x,i)=>(
                          <div key={i} style={{ display:'flex', gap:6, alignItems:'center' }}><span style={{ fontSize:13 }}>{x.i}</span><span style={{ fontSize:12, color:'#94a3b8' }}>{x.l}</span></div>
                        ))}
                      </div>
                      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', borderTop:'1px solid #1e2235', paddingTop:12 }}>
                        <div className={dc} style={{ fontSize:12, fontWeight:600 }}>{days<0?'🔴 Deadline passed':days===0?'🔴 Deadline today!':`⏰ ${days}d to deadline`}</div>
                        <a href={h.registrationLink} target="_blank" rel="noopener noreferrer" onClick={e=>e.stopPropagation()} style={{ background:'linear-gradient(135deg,#7c3aed,#a78bfa)', color:'#fff', textDecoration:'none', fontSize:12, fontWeight:700, padding:'6px 14px', borderRadius:8 }}>Register →</a>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
            <div style={{ textAlign:'center', marginTop:28 }}>
              <p style={{ color:'#475569', fontSize:13 }}>
                {loading ? 'Loading...' : `Showing ${hackathons.length} hackathons from database`}
              </p>
            </div>
          </div>
        )}

        {/* ── AI ASSIST ── */}
        {activeTab === 'ai-assist' && (
          <div className="pfade" style={{ maxWidth:820, margin:'0 auto', paddingTop:40 }}>
            <div style={{ textAlign:'center', marginBottom:32 }}>
              <div style={{ fontSize:48, marginBottom:12 }}>🤖</div>
              <h2 style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:28, fontWeight:700, color:'#fff', marginBottom:8 }}>AI Hackathon Assistant</h2>
              <p style={{ color:'#64748b' }}>Ask anything — powered by Claude AI via our backend.</p>
            </div>
            <div style={{ display:'flex', gap:8, flexWrap:'wrap', justifyContent:'center', marginBottom:20 }}>
              {['Best hackathons for beginners?','How to win a hackathon?','Local hackathons in Raipur?','Best AI/ML hackathons 2025?'].map(q=>(
                <button key={q} className="btn-ghost" style={{ fontSize:12 }} onClick={()=>setAiQuery(q)}>{q}</button>
              ))}
            </div>
            <div style={{ background:'#131620', border:'1px solid #2d3354', borderRadius:16, padding:20, marginBottom:24 }}>
              <textarea className="ptextarea" rows={3} placeholder="Ask HackBot anything..." value={aiQuery} onChange={e=>setAiQuery(e.target.value)} style={{ marginBottom:12, resize:'vertical' }} onKeyDown={e=>{ if(e.key==='Enter'&&e.ctrlKey) handleAskAI(); }}/>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <span style={{ fontSize:11, color:'#475569' }}>Ctrl+Enter to send</span>
                <button className="btn-primary" onClick={handleAskAI} disabled={aiLoading||!aiQuery.trim()}>
                  {aiLoading ? <span className="ppulse">🤖 Thinking...</span> : 'Ask HackBot ✨'}
                </button>
              </div>
            </div>
            {aiResponse && (
              <div className="pfade" style={{ background:'linear-gradient(135deg,#1a1040,#12162a)', border:'1px solid #3730a3', borderRadius:16, padding:24, marginBottom:32 }}>
                <div style={{ display:'flex', gap:10, alignItems:'flex-start' }}>
                  <div style={{ width:32, height:32, borderRadius:8, background:'linear-gradient(135deg,#7c3aed,#06b6d4)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:16, flexShrink:0 }}>🤖</div>
                  <div style={{ fontSize:14, color:'#cbd5e1', lineHeight:1.7, whiteSpace:'pre-wrap' }}>{aiResponse}</div>
                </div>
              </div>
            )}
            <h3 style={{ fontSize:16, fontWeight:700, color:'#94a3b8', marginBottom:16, display:'flex', alignItems:'center', gap:8 }}>
              <span style={{ display:'inline-block', width:24, height:2, background:'#a78bfa', borderRadius:1 }}/>AI-Curated Picks
            </h3>
            <div style={{ display:'grid', gap:12 }}>
              {AI_SUGGESTIONS.map((s,i)=>(
                <div key={i} style={{ background:'linear-gradient(135deg,#1a1040,#12162a)', border:'1px solid #3730a3', borderRadius:16, padding:20 }}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:12, flexWrap:'wrap' }}>
                    <div style={{ flex:1 }}>
                      <span style={{ display:'inline-block', fontSize:12, fontWeight:700, padding:'3px 10px', borderRadius:20, background:'#1e2235', color:'#a78bfa', marginBottom:6 }}>{s.badge}</span>
                      <h4 style={{ fontSize:16, fontWeight:700, color:'#fff', marginBottom:6 }}>{s.name}</h4>
                      <p style={{ fontSize:13, color:'#94a3b8', lineHeight:1.5 }}>💡 {s.why}</p>
                      <div style={{ marginTop:8, fontSize:12, color:'#64748b' }}>📅 Deadline: <span style={{ color:'#f59e0b' }}>{s.deadline}</span></div>
                    </div>
                    <a href={s.link} target="_blank" rel="noopener noreferrer" style={{ background:'#2d1f5e', color:'#a78bfa', textDecoration:'none', fontSize:12, fontWeight:700, padding:'8px 16px', borderRadius:8, border:'1px solid #3730a3', whiteSpace:'nowrap' }}>Explore →</a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── ADD HACKATHON ── */}
        {activeTab === 'add' && (
          <div className="pfade" style={{ maxWidth:680, margin:'0 auto', paddingTop:40 }}>
            <div style={{ textAlign:'center', marginBottom:32 }}>
              <div style={{ fontSize:48, marginBottom:12 }}>📢</div>
              <h2 style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:28, fontWeight:700, color:'#fff', marginBottom:8 }}>Share a Hackathon</h2>
              <p style={{ color:'#64748b' }}>Added hackathons are saved to the database and visible to everyone!</p>
            </div>
            <div style={{ background:'#131620', border:'1px solid #1e2235', borderRadius:20, padding:28 }}>
              {submitted ? (
                <div className="pfade" style={{ textAlign:'center', padding:40 }}>
                  <div style={{ fontSize:48, marginBottom:16 }}>🎉</div>
                  <h3 style={{ fontSize:20, fontWeight:700, color:'#10b981' }}>Hackathon Saved to Database!</h3>
                  <p style={{ color:'#64748b', marginTop:8 }}>It's now visible to all students on the platform.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit}>
                  <div style={{ display:'grid', gap:18 }}>
                    <div><label className="plabel">Hackathon Name *</label><input className="pinput" required placeholder="e.g. HackNITR 5.0" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></div>
                    <div className="grid2">
                      <div><label className="plabel">Organizer *</label><input className="pinput" required placeholder="e.g. NIT Rourkela" value={form.organizer} onChange={e=>setForm({...form,organizer:e.target.value})}/></div>
                      <div><label className="plabel">Mode</label><select className="pselect" value={form.mode} onChange={e=>setForm({...form,mode:e.target.value})}><option>Online</option><option>Offline</option><option>Hybrid</option></select></div>
                    </div>
                    <div className="grid2">
                      <div><label className="plabel">Start Date</label><input className="pinput" type="date" value={form.startDate} onChange={e=>setForm({...form,startDate:e.target.value})}/></div>
                      <div><label className="plabel">End Date</label><input className="pinput" type="date" value={form.endDate} onChange={e=>setForm({...form,endDate:e.target.value})}/></div>
                    </div>
                    <div className="grid2">
                      <div><label className="plabel">Registration Deadline *</label><input className="pinput" required type="date" value={form.deadline} onChange={e=>setForm({...form,deadline:e.target.value})}/></div>
                      <div><label className="plabel">Location</label><input className="pinput" placeholder="City, State or Remote" value={form.location} onChange={e=>setForm({...form,location:e.target.value})}/></div>
                    </div>
                    <div className="grid2">
                      <div><label className="plabel">Theme / Domain</label><input className="pinput" placeholder="e.g. AI, HealthTech" value={form.theme} onChange={e=>setForm({...form,theme:e.target.value})}/></div>
                      <div><label className="plabel">Prize Pool</label><input className="pinput" placeholder="e.g. ₹50,000" value={form.prize} onChange={e=>setForm({...form,prize:e.target.value})}/></div>
                    </div>
                    <div><label className="plabel">Description</label><textarea className="ptextarea" rows={3} value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Brief about the hackathon..."/></div>
                    <div><label className="plabel">Registration Link</label><input className="pinput" type="url" placeholder="https://..." value={form.registrationLink} onChange={e=>setForm({...form,registrationLink:e.target.value})}/></div>
                    <div><label className="plabel">Tags (comma separated)</label><input className="pinput" placeholder="e.g. local, ai, college" value={form.tags} onChange={e=>setForm({...form,tags:e.target.value})}/></div>
                    <button type="submit" className="btn-primary" disabled={submitting} style={{ padding:'14px', fontSize:15, borderRadius:12 }}>
                      {submitting ? '⏳ Saving...' : '🚀 Submit to Database'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        )}
      </div>

      {/* MODAL */}
      {modal && (
        <div className="modal-overlay" onClick={()=>setModal(null)}>
          <div className="modal pfade" onClick={e=>e.stopPropagation()}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:20 }}>
              <div>
                <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginBottom:8 }}>
                  {modal.tags.map(t=><span key={t} className="htag" style={{ background:(TAG_COLORS[t]||'#a78bfa')+'22', color:TAG_COLORS[t]||'#a78bfa' }}>{t}</span>)}
                </div>
                <h2 style={{ fontSize:22, fontWeight:700, color:'#fff' }}>{modal.name}</h2>
                <div style={{ color:'#64748b', fontSize:13, marginTop:2 }}>{modal.organizer}</div>
              </div>
              <button onClick={()=>setModal(null)} style={{ background:'#1e2235', border:'none', color:'#94a3b8', width:32, height:32, borderRadius:8, cursor:'pointer', fontSize:16, flexShrink:0 }}>✕</button>
            </div>
            <p style={{ color:'#94a3b8', fontSize:14, lineHeight:1.6, marginBottom:20 }}>{modal.description}</p>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginBottom:20 }}>
              {[{l:'Start Date',v:fmtDate(modal.startDate),i:'📅'},{l:'End Date',v:modal.endDate?fmtDate(modal.endDate):'TBA',i:'🏁'},{l:'Deadline',v:fmtDate(modal.deadline),i:'⏰'},{l:'Mode',v:modal.mode,i:'💻'},{l:'Location',v:modal.location,i:'📍'},{l:'Prize',v:modal.prize||'TBA',i:'🏆'},{l:'Theme',v:modal.theme,i:'💡'}].map((x,i)=>(
                <div key={i} style={{ background:'#1a1d27', borderRadius:10, padding:'12px 14px' }}>
                  <div style={{ fontSize:11, color:'#475569', fontWeight:600, textTransform:'uppercase', marginBottom:4 }}>{x.i} {x.l}</div>
                  <div style={{ fontSize:14, color:'#e2e8f0', fontWeight:500 }}>{x.v}</div>
                </div>
              ))}
            </div>
            <a href={modal.registrationLink} target="_blank" rel="noopener noreferrer" style={{ display:'block', textAlign:'center', background:'linear-gradient(135deg,#7c3aed,#a78bfa)', color:'#fff', textDecoration:'none', fontSize:15, fontWeight:700, padding:'14px', borderRadius:12 }}>🚀 Register Now</a>
          </div>
        </div>
      )}
    </div>
  );
}
