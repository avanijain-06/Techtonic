import { useState, useEffect, useCallback } from 'react';

const SLIDES = [
  {
    id: 's1',
    render: ({ onLaunch }) => (
      <div className="slide-inner" style={{ textAlign: 'center' }}>
        <div className="glow" style={{ width:500,height:500,background:'radial-gradient(circle,#00e5ff12,transparent 70%)',top:-100,left:-100 }}/>
        <div className="glow" style={{ width:400,height:400,background:'radial-gradient(circle,#a259ff12,transparent 70%)',bottom:-80,right:-80 }}/>
        <div className="logo-ring anim-1 floating">
          ⚡
          <div className="logo-spin-ring"/>
        </div>
        <h1 className="display anim-2" style={{ fontSize:'clamp(52px,8vw,96px)',marginBottom:16 }}>
          <span className="highlight">HackScout</span>
        </h1>
        <p className="anim-3" style={{ fontSize:'clamp(14px,2vw,18px)',color:'var(--soft)',maxWidth:520,lineHeight:1.6,margin:'0 auto' }}>
          A centralized hackathon discovery portal — find, share, and never miss opportunities. Powered by AI.
        </p>
        <div className="anim-4 team-badge">
          <span>🎓</span>
          <span>Hackathon Discovery Portal · PS-2</span>
          <span className="tag tag-cyan">Live Demo</span>
        </div>
      </div>
    )
  },
  {
    id: 's2',
    render: () => (
      <div className="slide-inner">
        <div className="glow" style={{ width:400,height:300,background:'radial-gradient(circle,#ff6b3514,transparent 70%)',top:0,right:0 }}/>
        <span className="tag tag-orange anim-1">The Problem</span>
        <h2 className="title anim-2" style={{ fontSize:'clamp(28px,4vw,48px)',margin:'12px 0',textAlign:'center' }}>
          Students Miss Hackathons<br/><span className="highlight2">Every. Single. Day.</span>
        </h2>
        <div className="anim-3 problem-grid">
          {[
            { icon:'🗂️', title:'Scattered Info', desc:'Opportunities spread across WhatsApp, LinkedIn, notice boards, and random sites' },
            { icon:'⏰', title:'Late Announcements', desc:'Students find out after registration deadlines have already passed' },
            { icon:'📍', title:'Local Events Hidden', desc:'Nearby college & state-level hackathons go unnoticed with no central platform' },
          ].map(c => (
            <div key={c.title} className="pcard" style={{ textAlign:'center' }}>
              <div style={{ fontSize:32,marginBottom:12 }}>{c.icon}</div>
              <h4 style={{ fontFamily:'Syne,sans-serif',fontSize:15,fontWeight:700,marginBottom:6 }}>{c.title}</h4>
              <p style={{ fontSize:13,color:'var(--soft)',lineHeight:1.5 }}>{c.desc}</p>
            </div>
          ))}
        </div>
        <div className="anim-4" style={{ display:'flex',gap:40,marginTop:28 }}>
          {[['73%','highlight','students miss deadlines'],['5+','highlight2','platforms to check daily'],['0','purple','centralized solutions']].map(([v,c,l])=>(
            <div key={l} style={{ textAlign:'center' }}>
              <div className={c !== 'purple' ? c : ''} style={c==='purple'?{fontFamily:'Syne,sans-serif',fontSize:36,fontWeight:800,color:'#a259ff'}:{fontFamily:'Syne,sans-serif',fontSize:36,fontWeight:800}}>{v}</div>
              <div style={{ fontSize:12,color:'var(--soft)' }}>{l}</div>
            </div>
          ))}
        </div>
      </div>
    )
  },
  {
    id: 's3',
    render: () => (
      <div className="slide-inner" style={{ textAlign:'center' }}>
        <div className="glow" style={{ width:500,height:400,background:'radial-gradient(circle,#00e5ff0e,transparent 70%)',top:'50%',left:'50%',transform:'translate(-50%,-50%)' }}/>
        <span className="tag tag-cyan anim-1">Our Solution</span>
        <h2 className="title anim-2" style={{ fontSize:'clamp(28px,4vw,48px)',margin:'12px 0' }}>
          One Platform. All Hackathons.<br/><span className="highlight">Zero Missed Opportunities.</span>
        </h2>
        <div className="anim-3 features-grid">
          {[
            { bg:'#00e5ff15', icon:'🔍', title:'Smart Discovery', desc:'Browse, search & filter hackathons by mode, location, tags, and deadlines' },
            { bg:'#a259ff15', icon:'🤖', title:'AI-Powered Suggestions', desc:'Ask HackBot — get personalized picks, prep tips, team strategies instantly' },
            { bg:'#ff6b3515', icon:'➕', title:'Community-Driven', desc:'Students & teachers add local hackathons — crowdsourced discovery' },
            { bg:'#ffcc0215', icon:'⏰', title:'Deadline Alerts', desc:'Visual urgency indicators show days left before each registration closes' },
          ].map(f => (
            <div key={f.title} className="feat-card">
              <div className="feat-icon" style={{ background:f.bg }}>{f.icon}</div>
              <div>
                <h4 style={{ fontFamily:'Syne,sans-serif',fontSize:14,fontWeight:700,marginBottom:4 }}>{f.title}</h4>
                <p style={{ fontSize:12,color:'var(--soft)',lineHeight:1.5 }}>{f.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  },
  {
    id: 's4',
    render: ({ onLaunch }) => (
      <div className="slide-inner">
        <div className="glow" style={{ width:400,height:300,background:'radial-gradient(circle,#a259ff12,transparent 70%)',bottom:0,left:0 }}/>
        <span className="tag tag-purple anim-1">Tech Stack</span>
        <h2 className="title anim-2" style={{ fontSize:'clamp(24px,3.5vw,40px)',margin:'12px 0',textAlign:'center' }}>
          Built with Modern,<br/><span className="highlight">Production-Ready Tools</span>
        </h2>
        <div className="anim-3 stack-grid">
          {[
            { icon:'⚛️', title:'React.js', desc:'Component-based UI with hooks', border:'var(--accent)' },
            { icon:'🤖', title:'Claude AI API', desc:"Anthropic's Claude powers HackBot", border:'var(--accent3)' },
            { icon:'🟢', title:'Node.js + Express', desc:'REST API backend server', border:'#22c55e' },
            { icon:'🗄️', title:'SQLite DB', desc:'Lightweight persistent storage', border:'var(--accent2)' },
            { icon:'🐙', title:'GitHub Pages', desc:'Free CI/CD deployment', border:'#94a3b8' },
            { icon:'🔗', title:'REST API', desc:'Clean JSON endpoints', border:'#f59e0b' },
          ].map(s => (
            <div key={s.title} className="pcard" style={{ textAlign:'center',borderTop:`2px solid ${s.border}` }}>
              <div style={{ fontSize:28,marginBottom:8 }}>{s.icon}</div>
              <h4 style={{ fontFamily:'Syne,sans-serif',fontSize:13,fontWeight:700,marginBottom:3 }}>{s.title}</h4>
              <p style={{ fontSize:11,color:'var(--soft)' }}>{s.desc}</p>
            </div>
          ))}
        </div>
        <div className="anim-4 flow-row">
          {['Client (React)','→','Express API','→','SQLite DB','→','Claude AI'].map((s,i) => (
            s === '→'
              ? <span key={i} style={{ color:'var(--muted)',fontSize:18 }}>→</span>
              : <div key={i} className="flow-item">{s}</div>
          ))}
        </div>
      </div>
    )
  },
  {
    id: 's5',
    render: () => (
      <div className="slide-inner" style={{ textAlign:'center' }}>
        <div className="glow" style={{ width:400,height:300,background:'radial-gradient(circle,#00e5ff0e,transparent 70%)',top:0,right:0 }}/>
        <span className="tag tag-cyan anim-1">Impact & Roadmap</span>
        <h2 className="title anim-2" style={{ fontSize:'clamp(24px,3.5vw,40px)',margin:'12px 0' }}>
          Solving a Real Problem<br/><span className="highlight">At Scale</span>
        </h2>
        <div className="anim-3 impact-row">
          {[['6+','highlight','Hackathons Listed'],['∞','highlight2','Community Submissions'],['AI','purple','Powered Suggestions'],['0₹','highlight','Cost to Students']].map(([v,c,l])=>(
            <div key={l} className="imp-card">
              <div className={c==='purple'?'':''+c} style={c==='purple'?{fontFamily:'Syne,sans-serif',fontSize:40,fontWeight:800,color:'#a259ff'}:{fontFamily:'Syne,sans-serif',fontSize:40,fontWeight:800}}>{v}</div>
              <div style={{ fontSize:12,color:'var(--soft)',marginTop:4 }}>{l}</div>
            </div>
          ))}
        </div>
        <div className="anim-4 future-grid">
          {['📧 Email deadline alerts','🔐 Student login & saved hackathons','📱 Mobile app (React Native)','👥 Team formation & matchmaking','🏫 College-specific feeds','📊 Analytics dashboard'].map(f=>(
            <div key={f} className="f-item">{f}</div>
          ))}
        </div>
      </div>
    )
  },
  {
    id: 's6',
    render: ({ onLaunch }) => (
      <div className="slide-inner" style={{ textAlign:'center' }}>
        <div className="glow" style={{ width:600,height:600,background:'radial-gradient(circle,#00e5ff0a,transparent 70%)',top:'50%',left:'50%',transform:'translate(-50%,-50%)' }}/>
        <span className="tag tag-cyan anim-1">Thank You</span>
        <h1 className="display anim-2" style={{ fontSize:'clamp(40px,7vw,80px)',margin:'12px 0' }}>
          <span className="highlight">Never Miss a</span><br/>Hackathon Again.
        </h1>
        <p className="anim-3" style={{ color:'var(--soft)',fontSize:16,marginBottom:32 }}>
          HackScout — Built for students, by students. Powered by Claude AI + React + Node.js
        </p>
        <button className="launch-btn anim-4" onClick={onLaunch}>
          🚀 Launch Live Portal
        </button>
        <p className="anim-5" style={{ marginTop:16,fontSize:12,color:'var(--muted)' }}>Click to open the fully working app</p>
      </div>
    )
  },
];

export default function Pitch({ onLaunch }) {
  const [current, setCurrent] = useState(0);
  const total = SLIDES.length;

  const goTo = useCallback((n) => {
    setCurrent(((n % total) + total) % total);
  }, [total]);

  useEffect(() => {
    const handler = (e) => {
      if (e.key === 'ArrowRight' || e.key === 'ArrowDown') goTo(current + 1);
      if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') goTo(current - 1);
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [current, goTo]);

  // Touch swipe
  useEffect(() => {
    let tx = 0;
    const ts = (e) => { tx = e.touches[0].clientX; };
    const te = (e) => {
      const dx = tx - e.changedTouches[0].clientX;
      if (Math.abs(dx) > 50) goTo(current + (dx > 0 ? 1 : -1));
    };
    window.addEventListener('touchstart', ts);
    window.addEventListener('touchend', te);
    return () => { window.removeEventListener('touchstart', ts); window.removeEventListener('touchend', te); };
  }, [current, goTo]);

  const progressPct = ((current + 1) / total) * 100;

  return (
    <div id="pitch-app">
      {/* Progress */}
      <div id="progress" style={{ width: `${progressPct}%` }} />

      {/* Keyboard hint */}
      <div id="hint"><kbd>←</kbd> <kbd>→</kbd> to navigate</div>

      {/* Slides */}
      {SLIDES.map((slide, i) => (
        <div key={slide.id} className={`slide ${i === current ? 'active' : ''}`}>
          <div className="grid-bg" />
          {slide.render({ onLaunch })}
        </div>
      ))}

      {/* Nav */}
      <div id="pitch-nav">
        <button className="nav-btn" onClick={() => goTo(current - 1)}>←</button>
        <div className="nav-dots">
          {SLIDES.map((_, i) => (
            <div key={i} className={`dot ${i === current ? 'active' : ''}`} onClick={() => goTo(i)} />
          ))}
        </div>
        <span id="slide-counter">{current + 1} / {total}</span>
        <button className="nav-btn" onClick={() => goTo(current + 1)}>→</button>
      </div>
    </div>
  );
}
