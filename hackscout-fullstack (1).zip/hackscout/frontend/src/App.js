import { useState } from 'react';
import Pitch from './Pitch';
import Portal from './Portal';
import './styles.css';

export default function App() {
  const [view, setView] = useState('pitch'); // 'pitch' | 'portal'
  return (
    <div id="app-shell">
      <div id="pitch-view" className={view === 'portal' ? 'hidden' : ''}>
        <Pitch onLaunch={() => setView('portal')} />
      </div>
      <div id="portal-view" className={view === 'portal' ? 'visible' : ''}>
        {view === 'portal' && (
          <button id="back-btn" onClick={() => setView('pitch')}>← Back to Pitch</button>
        )}
        <Portal />
      </div>
    </div>
  );
}
