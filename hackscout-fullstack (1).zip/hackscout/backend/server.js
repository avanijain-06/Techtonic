require('dotenv').config();
const express = require('express');
const cors = require('cors');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 5000;

// ── Middleware ──────────────────────────────────────────
app.use(cors({ origin: ['http://localhost:3000', 'http://127.0.0.1:3000'] }));
app.use(express.json());

// Request logger
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  next();
});

// ── HELPERS ─────────────────────────────────────────────
function parseHackathon(row) {
  if (!row) return null;
  return {
    ...row,
    tags: (() => { try { return JSON.parse(row.tags); } catch { return []; } })(),
    featured: row.featured === 1,
  };
}

// ── ROUTES ──────────────────────────────────────────────

// GET /api/hackathons — list all with optional search & filters
app.get('/api/hackathons', (req, res) => {
  try {
    const { search, mode, tag } = req.query;
    let query = 'SELECT * FROM hackathons WHERE 1=1';
    const params = [];

    if (search) {
      query += ` AND (
        name LIKE ? OR theme LIKE ? OR location LIKE ? OR organizer LIKE ?
      )`;
      const s = `%${search}%`;
      params.push(s, s, s, s);
    }
    if (mode && mode !== 'All') {
      query += ' AND mode = ?';
      params.push(mode);
    }

    query += ' ORDER BY featured DESC, createdAt DESC';

    let rows = db.prepare(query).all(...params).map(parseHackathon);

    // tag filter (done in JS since tags is JSON array)
    if (tag && tag !== 'All') {
      rows = rows.filter(h => h.tags.includes(tag.toLowerCase()));
    }

    res.json({ success: true, data: rows, total: rows.length });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// GET /api/hackathons/:id — get single hackathon
app.get('/api/hackathons/:id', (req, res) => {
  try {
    const row = db.prepare('SELECT * FROM hackathons WHERE id = ?').get(req.params.id);
    if (!row) return res.status(404).json({ success: false, message: 'Hackathon not found' });
    res.json({ success: true, data: parseHackathon(row) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// POST /api/hackathons — add new hackathon
app.post('/api/hackathons', (req, res) => {
  try {
    const {
      name, organizer, theme, mode, location,
      startDate, endDate, deadline, prize,
      description, registrationLink, tags, featured
    } = req.body;

    if (!name || !organizer || !deadline) {
      return res.status(400).json({ success: false, message: 'name, organizer, and deadline are required' });
    }

    const stmt = db.prepare(`
      INSERT INTO hackathons
        (name, organizer, theme, mode, location, startDate, endDate, deadline, prize, description, registrationLink, tags, featured)
      VALUES
        (@name, @organizer, @theme, @mode, @location, @startDate, @endDate, @deadline, @prize, @description, @registrationLink, @tags, @featured)
    `);

    const result = stmt.run({
      name,
      organizer,
      theme: theme || '',
      mode: mode || 'Online',
      location: location || '',
      startDate: startDate || '',
      endDate: endDate || '',
      deadline,
      prize: prize || '',
      description: description || '',
      registrationLink: registrationLink || '',
      tags: JSON.stringify(Array.isArray(tags) ? tags : (tags || '').split(',').map(t => t.trim().toLowerCase()).filter(Boolean)),
      featured: featured ? 1 : 0,
    });

    const newRow = db.prepare('SELECT * FROM hackathons WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json({ success: true, data: parseHackathon(newRow), message: 'Hackathon added successfully!' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// DELETE /api/hackathons/:id — delete a hackathon
app.delete('/api/hackathons/:id', (req, res) => {
  try {
    const result = db.prepare('DELETE FROM hackathons WHERE id = ?').run(req.params.id);
    if (result.changes === 0) return res.status(404).json({ success: false, message: 'Not found' });
    res.json({ success: true, message: 'Deleted successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// GET /api/tags — get all unique tags
app.get('/api/tags', (req, res) => {
  try {
    const rows = db.prepare('SELECT tags FROM hackathons').all();
    const allTags = [...new Set(
      rows.flatMap(r => { try { return JSON.parse(r.tags); } catch { return []; } })
    )].sort();
    res.json({ success: true, data: allTags });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// GET /api/stats — dashboard stats
app.get('/api/stats', (req, res) => {
  try {
    const total    = db.prepare('SELECT COUNT(*) as c FROM hackathons').get().c;
    const online   = db.prepare("SELECT COUNT(*) as c FROM hackathons WHERE mode='Online'").get().c;
    const offline  = db.prepare("SELECT COUNT(*) as c FROM hackathons WHERE mode='Offline'").get().c;
    const featured = db.prepare('SELECT COUNT(*) as c FROM hackathons WHERE featured=1').get().c;
    res.json({ success: true, data: { total, online, offline, featured } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// POST /api/ai/chat — proxy to Claude AI
app.post('/api/ai/chat', async (req, res) => {
  try {
    const { query } = req.body;
    if (!query) return res.status(400).json({ success: false, message: 'query is required' });

    const hackathons = db.prepare('SELECT name, mode, location, deadline FROM hackathons ORDER BY deadline').all();
    const hackList = hackathons.map(h => `${h.name} (${h.mode}, ${h.location}, deadline: ${h.deadline})`).join('\n');

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: `You are HackBot, AI assistant for HackScout — a hackathon portal for Indian students. Be concise, enthusiastic, and actionable. Current hackathons in the system:\n${hackList}`,
        messages: [{ role: 'user', content: query }],
      }),
    });

    const data = await response.json();
    const text = data.content?.[0]?.text || "Sorry, couldn't generate a response.";
    res.json({ success: true, data: { response: text } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'AI service error' });
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ success: true, message: '✅ HackScout API is running', timestamp: new Date().toISOString() });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Route ${req.url} not found` });
});

// Start server
app.listen(PORT, () => {
  console.log(`\n🚀 HackScout API running at http://localhost:${PORT}`);
  console.log(`📋 Endpoints:`);
  console.log(`   GET  /api/hackathons         - List all hackathons`);
  console.log(`   GET  /api/hackathons/:id      - Get single hackathon`);
  console.log(`   POST /api/hackathons          - Add new hackathon`);
  console.log(`   DELETE /api/hackathons/:id   - Delete hackathon`);
  console.log(`   GET  /api/tags               - Get all tags`);
  console.log(`   GET  /api/stats              - Get dashboard stats`);
  console.log(`   POST /api/ai/chat            - AI HackBot`);
  console.log(`   GET  /api/health             - Health check\n`);
});
