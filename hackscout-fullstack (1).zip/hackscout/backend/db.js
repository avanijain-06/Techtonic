const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'hackscout.db'));

// Enable WAL mode for better performance
db.pragma('journal_mode = WAL');

// Create tables
db.exec(`
  CREATE TABLE IF NOT EXISTS hackathons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    organizer TEXT NOT NULL,
    theme TEXT,
    mode TEXT CHECK(mode IN ('Online', 'Offline', 'Hybrid')) DEFAULT 'Online',
    location TEXT,
    startDate TEXT,
    endDate TEXT,
    deadline TEXT NOT NULL,
    prize TEXT,
    description TEXT,
    registrationLink TEXT,
    tags TEXT DEFAULT '[]',
    featured INTEGER DEFAULT 0,
    createdAt TEXT DEFAULT (datetime('now'))
  );
`);

// Seed data only if table is empty
const count = db.prepare('SELECT COUNT(*) as c FROM hackathons').get();
if (count.c === 0) {
  const insert = db.prepare(`
    INSERT INTO hackathons (name, organizer, theme, mode, location, startDate, endDate, deadline, prize, description, registrationLink, tags, featured)
    VALUES (@name, @organizer, @theme, @mode, @location, @startDate, @endDate, @deadline, @prize, @description, @registrationLink, @tags, @featured)
  `);

  const seed = db.transaction((hackathons) => {
    for (const h of hackathons) insert.run(h);
  });

  seed([
    {
      name: 'Smart India Hackathon 2025',
      organizer: 'Ministry of Education, India',
      theme: 'EdTech, HealthTech, Smart Cities',
      mode: 'Hybrid',
      location: 'Pan India',
      startDate: '2025-08-01',
      endDate: '2025-08-03',
      deadline: '2025-06-30',
      prize: '₹1,00,000',
      description: "India's biggest national hackathon solving real-world problems across multiple sectors.",
      registrationLink: 'https://sih.gov.in',
      tags: JSON.stringify(['national', 'government', 'edtech']),
      featured: 1,
    },
    {
      name: 'HackWithInfy 2025',
      organizer: 'Infosys',
      theme: 'AI/ML, Sustainability, Digital Transformation',
      mode: 'Online',
      location: 'Remote',
      startDate: '2025-07-12',
      endDate: '2025-07-13',
      deadline: '2025-06-15',
      prize: '₹50,000',
      description: "Infosys's flagship hackathon for engineering students across India.",
      registrationLink: 'https://hackwithinfy.com',
      tags: JSON.stringify(['corporate', 'ai', 'online']),
      featured: 1,
    },
    {
      name: 'Hack36 — MNNIT Allahabad',
      organizer: 'MNNIT Allahabad',
      theme: 'Open Innovation',
      mode: 'Offline',
      location: 'Allahabad, UP',
      startDate: '2025-04-05',
      endDate: '2025-04-07',
      deadline: '2025-03-20',
      prize: '₹75,000',
      description: '36-hour hackathon organized by students of MNNIT Allahabad.',
      registrationLink: 'https://hack36.com',
      tags: JSON.stringify(['college', 'offline', 'open']),
      featured: 0,
    },
    {
      name: 'CodeChef SnackDown 2025',
      organizer: 'CodeChef',
      theme: 'Competitive Programming',
      mode: 'Online',
      location: 'Remote',
      startDate: '2025-09-10',
      endDate: '2025-09-12',
      deadline: '2025-08-25',
      prize: '$5,000',
      description: 'Global coding championship open to teams of 2 from around the world.',
      registrationLink: 'https://codechef.com/snackdown',
      tags: JSON.stringify(['competitive', 'global', 'coding']),
      featured: 0,
    },
    {
      name: 'NIT Raipur HackFest',
      organizer: 'NIT Raipur Tech Club',
      theme: 'AgriTech, Rural Innovation',
      mode: 'Offline',
      location: 'Raipur, Chhattisgarh',
      startDate: '2025-05-20',
      endDate: '2025-05-21',
      deadline: '2025-05-01',
      prize: '₹30,000',
      description: 'Local hackathon focused on AgriTech and rural development solutions.',
      registrationLink: '#',
      tags: JSON.stringify(['local', 'college', 'agritech']),
      featured: 0,
    },
    {
      name: 'Chhattisgarh Startup Hackathon',
      organizer: 'CG Startup Mission',
      theme: 'Startup & Entrepreneurship',
      mode: 'Hybrid',
      location: 'Raipur, CG',
      startDate: '2025-06-14',
      endDate: '2025-06-15',
      deadline: '2025-06-01',
      prize: '₹2,00,000 + Incubation',
      description: 'State-level hackathon by the Chhattisgarh government to nurture startup ideas.',
      registrationLink: '#',
      tags: JSON.stringify(['local', 'startup', 'government']),
      featured: 1,
    },
  ]);

  console.log('✅ Database seeded with 6 hackathons');
}

module.exports = db;
