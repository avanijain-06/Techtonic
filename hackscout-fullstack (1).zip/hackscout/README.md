# ⚡ HackScout — Full Stack Hackathon Discovery Portal

> Pitch deck + live portal + real backend. Built with React, Node.js, Express, SQLite, and Claude AI.

---

## 📁 Project Structure

```
hackscout/
├── backend/
│   ├── server.js        ← Express API server
│   ├── db.js            ← SQLite database + seed data
│   ├── .env             ← API keys (add your Anthropic key here)
│   └── package.json
│
├── frontend/
│   ├── src/
│   │   ├── index.js     ← React entry point
│   │   ├── App.js       ← Root: switches between Pitch & Portal
│   │   ├── Pitch.js     ← 6-slide animated pitch deck
│   │   ├── Portal.js    ← Full hackathon portal (talks to backend)
│   │   ├── api.js       ← All API calls to the backend
│   │   └── styles.css   ← All styles
│   ├── public/
│   │   └── index.html
│   └── package.json
│
└── README.md
```

---

## 🚀 Quick Setup (5 minutes)

### Step 1 — Clone & Install

```bash
# Backend
cd hackscout/backend
npm install

# Frontend
cd ../frontend
npm install
```

### Step 2 — Add your Anthropic API Key

Open `backend/.env` and replace the placeholder:

```env
PORT=5000
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxxxxxxxxxxxxx
```

Get your key at: https://console.anthropic.com

### Step 3 — Start the Backend

```bash
cd backend
npm start
# or for auto-reload during development:
npm run dev
```

You should see:
```
🚀 HackScout API running at http://localhost:5000
✅ Database seeded with 6 hackathons
```

### Step 4 — Start the Frontend

Open a **new terminal**:

```bash
cd frontend
npm start
```

Opens at **http://localhost:3000** automatically.

---

## 🔌 API Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/hackathons` | List all hackathons |
| GET | `/api/hackathons?search=ai` | Search hackathons |
| GET | `/api/hackathons?mode=Online` | Filter by mode |
| GET | `/api/hackathons?tag=local` | Filter by tag |
| GET | `/api/hackathons/:id` | Get single hackathon |
| POST | `/api/hackathons` | Add new hackathon |
| DELETE | `/api/hackathons/:id` | Delete hackathon |
| GET | `/api/tags` | Get all unique tags |
| GET | `/api/stats` | Get dashboard stats |
| POST | `/api/ai/chat` | Ask HackBot (Claude AI) |
| GET | `/api/health` | Health check |

### Example API calls

```bash
# Get all hackathons
curl http://localhost:5000/api/hackathons

# Search
curl "http://localhost:5000/api/hackathons?search=raipur&mode=Offline"

# Add hackathon
curl -X POST http://localhost:5000/api/hackathons \
  -H "Content-Type: application/json" \
  -d '{"name":"My Hackathon","organizer":"My College","deadline":"2025-09-01","mode":"Online"}'

# Ask AI
curl -X POST http://localhost:5000/api/ai/chat \
  -H "Content-Type: application/json" \
  -d '{"query":"Best hackathons for beginners?"}'
```

---

## 🌐 Deploy to GitHub Pages

```bash
# 1. Edit frontend/package.json — replace with your GitHub username:
"homepage": "https://YOUR_USERNAME.github.io/hackscout"

# 2. Build and deploy
cd frontend
npm run deploy
```

> Note: For production, deploy the backend to Railway, Render, or Vercel (serverless functions).

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, CSS3 |
| Backend | Node.js, Express |
| Database | SQLite (via better-sqlite3) |
| AI | Claude API (Anthropic) |
| Hosting | GitHub Pages (frontend) |

---

## ✨ Features

- 🎯 **7-slide animated pitch deck** — present to judges
- 🔍 **Search & filter** hackathons by name, mode, tag
- 📊 **Live stats** from real database
- 🤖 **HackBot AI** powered by Claude — answers via backend
- ➕ **Add hackathons** — saved to SQLite database persistently
- 📋 **Detail modals** for each hackathon
- ⏰ **Deadline urgency** indicators
- 🌐 **REST API** — clean, documented endpoints
